const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// Enable CORS for web clients
app.use((req, res, next) => {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.header("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
    if (req.method === 'OPTIONS') {
        return res.sendStatus(200);
    }
    next();
});

// Mock 3rd Party Environmental Weather API
async function verifyEnvironmentalStatus(lat, lon, timestamp) {
    // In production, this would call OpenWeatherMap History API
    // Mock response simulating weather mismatch
    console.log(`[API] Checking environmental data for ${lat}, ${lon} at ${timestamp}`);
    return "clear skies, sunny"; 
}

// Mock IP Geolocation API
async function verifyIPGeolocation(ip, claimedLat, claimedLon) {
    // In production, this would call MaxMind or IPAPI
    console.log(`[API] Checking IP Geometry mapping...`);
    // Hardcoding a mismatch simulator for VPN usage:
    return { match: false, reason: "IP locates to New York, GPS claims otherwise" };
}

// Receive Claim from Flutter Client
app.post('/api/claims/submit', async (req, res) => {
    try {
        const claim = req.body;
        console.log(`[Backend Received Claim] ID: ${claim.id}`);

        // 1. Gather 3rd Party Data
        const actualWeather = await verifyEnvironmentalStatus(claim.gps_lat, claim.gps_lon, claim.timestamp);
        
        // Extracted IP (In real app, req.ip or x-forwarded-for)
        const requestIP = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
        const ipGeoStatus = await verifyIPGeolocation(requestIP, claim.gps_lat, claim.gps_lon);
        
        // Measure Time Mismatch (Tampered Clock Detection)
        const serverTime = new Date().getTime();
        const clientTime = new Date(claim.timestamp).getTime();
        const timeTampered = Math.abs(serverTime - clientTime) > 300000; // Flag if off by > 5 minutes
        
        // 2. Attach enriched metadata for ML Engine
        const enrichedClaim = {
            ...claim,
            api_weather_data: actualWeather,
            ip_geo_status: ipGeoStatus,
            time_tampered: timeTampered
        };

        // 3. Send payload to ML Engine (Flask API running on 5000)
        // Ensure python service is running
        try {
            const mlResponse = await axios.post('http://localhost:5000/api/v1/score', enrichedClaim);
            const riskData = mlResponse.data;
            
            // 4. Return Final Verified Status to Client
            if (riskData.status === "MANUAL_REVIEW" || riskData.status === "REJECTED_FRAUD") {
                // Can trigger websocket to admin dashboard here
                console.log(`[ALERT] HIGH RISK DETECTED: Score ${riskData.risk_score}`);
            }

            res.status(200).json({
                success: true,
                message: "Claim submitted and analyzed.",
                validation_result: riskData
            });

        } catch(mlErr) {
            console.error("Machine Learning engine is down. Cannot authorize claim.", mlErr.message);
            res.status(503).json({ error: "Risk Scoring Engine Unavailable" });
        }
        
    } catch (error) {
        console.error("Error processing claim:", error.message);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Fraud Verification Service running on port ${PORT}`);
});
