import 'package:flutter/material.dart';
import 'screens/claim_screen.dart';

void main() {
  runApp(const FraudGuardApp());
}

class FraudGuardApp extends StatelessWidget {
  const FraudGuardApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FraudGuard AI',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        brightness: Brightness.dark,
      ),
      home: ClaimSubmissionScreen(),
    );
  }
}
