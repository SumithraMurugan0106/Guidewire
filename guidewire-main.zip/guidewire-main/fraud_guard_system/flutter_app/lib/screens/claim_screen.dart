import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../services/sensor_service.dart';
import '../services/location_service.dart';

class ClaimSubmissionScreen extends StatefulWidget {
  @override
  _ClaimSubmissionScreenState createState() => _ClaimSubmissionScreenState();
}

class _ClaimSubmissionScreenState extends State<ClaimSubmissionScreen> {
  final SensorService _sensorService = SensorService();
  final LocationService _locationService = LocationService();
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    // Start capturing background sensor jitter immediately 
    // to detect real vs synthetic behavior
    _sensorService.startRecording();
  }

  Future<void> submitClaim() async {
    setState(() { _isSubmitting = true; });
    
    // 1. Gather hardware location telemetry
    final locationData = await _locationService.getCurrentLocation();
    
    // 2. Gather device IMU anomalies
    final sensorMetrics = _sensorService.getSensorMetrics();

    // 3. Construct fraud payload
    final payload = {
        "id": "CLM-${DateTime.now().millisecondsSinceEpoch}",
        "timestamp": DateTime.now().toIso8601String(),
        "mock_location_enabled": locationData['mock_location_enabled'] ?? false,
        //"mock_location_enabled": true,
        "gps_lat": locationData['lat'],
        "gps_lon": locationData['lon'],
        "sensor_data": sensorMetrics,
        // In reality, this jump data is calculated server-side based on previous pings
        "last_jump_km": 0, 
        "time_since_last_ping_sec": 60,
        "reported_weather": "heavy rain" // User input or local API gathering
    };

    try {
      final response = await http.post(
        Uri.parse('http://localhost:3000/api/claims/submit'), // Localhost for web/desktop
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(payload)
      );

      final responseData = jsonDecode(response.body);
      
      if (response.statusCode == 200) {
        final riskStatus = responseData['validation_result']['status'];
        _showAlert(riskStatus == "APPROVED" 
            ? "Claim Approved successfully." 
            : "Claim under manual investigation due to irregularities.");
      }
    } catch (e) {
      _showAlert("Network Error: Could not connect to verification server.");
    } finally {
      setState(() { _isSubmitting = false; });
    }
  }

  void _showAlert(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Claim Status"),
        content: Text(message),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text("OK"))
        ],
      )
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Submit Claim")),
      body: Center(
        child: _isSubmitting 
            ? CircularProgressIndicator()
            : ElevatedButton(
                onPressed: submitClaim,
                child: Text("Submit Geo-Tagged Claim"),
              ),
      ),
    );
  }
}
