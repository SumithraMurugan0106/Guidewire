import 'package:geolocator/geolocator.dart';

class LocationService {
  Future<Map<String, dynamic>> getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return {"error": "Location services disabled."};
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return {"error": "Location permissions denied."};
      }
    }
    
    if (permission == LocationPermission.deniedForever) {
      return {"error": "Location permissions permanently denied."};
    } 

    Position position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
    
    // The 'isMocked' property comes directly from Android's geolocation integrity subsystem
    return {
      "lat": position.latitude,
      "lon": position.longitude,
      "mock_location_enabled": position.isMocked, // Core logic identifying fake GPS apps
      "timestamp": position.timestamp?.toIso8601String(),
    };
  }
}
