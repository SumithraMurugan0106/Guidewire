import 'dart:math';
import 'package:sensors_plus/sensors_plus.dart';

class SensorService {
  List<double> _gyroData = [];
  List<double> _accelData = [];
  
  void startRecording() {
    _gyroData.clear();
    _accelData.clear();
    
    // Sample sensors for a brief period to detect real human jitter
    gyroscopeEvents.listen((GyroscopeEvent event) {
      if (_gyroData.length < 50) {
        _gyroData.add(sqrt(pow(event.x, 2) + pow(event.y, 2) + pow(event.z, 2)));
      }
    });
    
    userAccelerometerEvents.listen((UserAccelerometerEvent event) {
      if (_accelData.length < 50) {
        _accelData.add(sqrt(pow(event.x, 2) + pow(event.y, 2) + pow(event.z, 2)));
      }
    });
  }

  double _calculateVariance(List<double> values) {
    if (values.isEmpty) return 0.0;
    double mean = values.reduce((a, b) => a + b) / values.length;
    double sumSq = values.map((v) => pow(v - mean, 2)).reduce((a, b) => a + b).toDouble();
    return sumSq / values.length;
  }

  Map<String, dynamic> getSensorMetrics() {
    return {
      "gyroscope_variance": _calculateVariance(_gyroData),
      "accelerometer_variance": _calculateVariance(_accelData),
    };
  }
}
