import json
from flask import Flask, request, jsonify
from fraud_model import FraudDetectionModel

app = Flask(__name__)
# Initialize the ML Engine
fraud_engine = FraudDetectionModel()

@app.route("/api/v1/score", methods=["POST"])
def score_claim():
    try:
        claim_data = request.json
        if not claim_data:
            return jsonify({"error": "No claim data provided"}), 400
        
        # Evaluate user claim
        risk_score = fraud_engine.evaluate_claim(claim_data)
        
        # Format response
        response = {
            "claim_id": claim_data.get("id", "UNKNOWN"),
            "risk_score": risk_score,
            "status": "APPROVED" if risk_score <= 30 else "MANUAL_REVIEW" if risk_score <= 60 else "REJECTED_FRAUD",
            "timestamp": claim_data.get("timestamp")
        }
        return jsonify(response), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(port=5000, debug=True)
