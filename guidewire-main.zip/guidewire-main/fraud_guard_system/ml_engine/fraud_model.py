import json
import logging
from datetime import datetime
import numpy as np
from sklearn.ensemble import IsolationForest

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("FraudMLEngine")

class FraudDetectionModel:
    def __init__(self):
        # We use an Isolation Forest to detect 'teleportation' anomalies
        # based on user history coordinates.
        self.model = IsolationForest(n_estimators=100, contamination=0.01, random_state=42)
        # Dummy "normal" paths for training. Features: [distance_from_last_ping_km, time_since_last_ping_sec]
        # In a real app, this is trained on massive datasets of normal driver behaviors.
        dummy_training_data = np.array([
            [0.1, 60],
            [1.5, 300],
            [0.0, 10],
            [5.0, 600],
            [2.5, 300]
        ])
        self.model.fit(dummy_training_data)
        logger.info("Fraud Detection Model initialized & trained.")

    def _assess_gps_anomaly(self, distance_km: float, time_delta_sec: float) -> int:
        """ Predict anomaly using IF model. Returns 1 for normal, -1 for anomalous """
        if time_delta_sec <= 0:
            return -1 # impossible
        prediction = self.model.predict([[distance_km, time_delta_sec]])
        return prediction[0]

    def _check_sensor_integrity(self, sensor_data: dict) -> bool:
        """ 
        Rule-based heuristic: check if IMU data is physically believable.
        Bots rarely perfectly fake jitter. 
        """
        gyro_variance = sensor_data.get("gyroscope_variance", 0.0)
        accel_variance = sensor_data.get("accelerometer_variance", 0.0)
        
        # Dead zero variance when making a claim is suspicious (indicates emulator or spoof)
        if gyro_variance < 0.001 or accel_variance < 0.001:
            return False 
        return True

    def _verify_environment(self, claim_weather: str, api_weather: str) -> bool:
        # Simplistic check
        return claim_weather.lower() in api_weather.lower()

    def evaluate_claim(self, claim_data: dict) -> int:
        """
        Evaluates a claim and returns a risk score 0 - 100.
        > 60 is flagged for review.
        """
        risk_score = 0
        
        # 1. Hardware Integrity Check
        if claim_data.get("mock_location_enabled", False):
            logger.warning(f"Claim {claim_data.get('id')}: Mock location API used!")
            risk_score += 50
        
        if claim_data.get("device_rooted", False):
            risk_score += 20

        # 2. GPS Jump / Teleportation ML Check
        jump_dist = claim_data.get("last_jump_km", 0)
        jump_time = claim_data.get("time_since_last_ping_sec", 60)
        
        anomaly = self._assess_gps_anomaly(jump_dist, jump_time)
        if anomaly == -1:
            logger.warning(f"Claim {claim_data.get('id')}: Anomalous GPS movement detected.")
            # Penalize heavily if they jumped significantly
            risk_score += min(45, int(jump_dist / max(1, jump_time) * 1000))
        
        # 3. IMU Sensor Integrity
        if not self._check_sensor_integrity(claim_data.get("sensor_data", {})):
            logger.info(f"Claim {claim_data.get('id')}: Synthetic IMU sensor data detected.")
            risk_score += 20

        # 4. Environmental Validation
        claim_env = claim_data.get("reported_weather", "")
        api_env = claim_data.get("api_weather_data", "")
        if claim_env and api_env:
            if not self._verify_environment(claim_env, api_env):
                logger.warning(f"Claim {claim_data.get('id')}: Weather mismatch.")
                risk_score += 15

        # 5. IP vs GPS Geolocation Mismatch Validation
        ip_geo = claim_data.get("ip_geo_status", {})
        if ip_geo.get("match") is False:
            logger.warning(f"Claim {claim_data.get('id')}: IP address location does not match GPS location (VPN / Spoofing likely).")
            risk_score += 25
            
        # 6. Device Time Tampering Detection
        if claim_data.get("time_tampered", False):
            logger.warning(f"Claim {claim_data.get('id')}: System clock tampering detected.")
            risk_score += 15

        # Cap score at 100
        return min(100, risk_score)

# Example Usage
if __name__ == "__main__":
    engine = FraudDetectionModel()
    
    # Simulate a fraudulent claim
    suspicious_claim = {
        "id": "CLM-1002",
        "mock_location_enabled": True,
        "device_rooted": False,
        "last_jump_km": 1500.0, # Jumped 1500KM
        "time_since_last_ping_sec": 300, # In 5 minutes (physically impossible)
        "sensor_data": {
            "gyroscope_variance": 0.000, # Pure zero indicates emulator
            "accelerometer_variance": 0.000 
        },
        "reported_weather": "heavy rain",
        "api_weather_data": "clear skies, sunny"
    }
    
    score = engine.evaluate_claim(suspicious_claim)
    print(f"\nEvaluating Claim [{suspicious_claim['id']}]")
    print(f"Computed Fraud Risk Score: {score}/100")
    if score > 60:
        print("ACTION: FLAGGED FOR MANUAL REVIEW - HIGH RISK OF SPOOFING.")
